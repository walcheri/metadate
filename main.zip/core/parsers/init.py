from .base_parser import BaseParser
from .pdf_parser import PDFParser
from .docx_parser import DocxParser
from .image_parser import ImageParser
from .excel_parser import ExcelParser
from .heic_parser import HEICParser  # Добавляем новый парсер
from typing import Optional

_PARSERS = [
    PDFParser(),
    DocxParser(),
    ImageParser(),
    ExcelParser(),
    HEICParser(),  # Добавляем HEIC парсер
]

def get_parser_for_file(file_path: str, mime_type: str = None) -> Optional[BaseParser]:
    """Возвращает подходящий парсер для файла"""
    for parser in _PARSERS:
        if mime_type and mime_type in parser.supported_formats():
            return parser
            
    # Попробуем определить по расширению, если mime-type не определился
    import os
    ext = os.path.splitext(file_path)[1].lower()
    
    ext_to_parser = {
        '.pdf': PDFParser,
        '.docx': DocxParser,
        '.xlsx': ExcelParser,
        '.jpg': ImageParser,
        '.jpeg': ImageParser,
        '.png': ImageParser,
        '.tiff': ImageParser,
        '.tif': ImageParser,
        '.heic': HEICParser,  # Добавляем HEIC
        '.heif': HEICParser,  # Добавляем HEIF
    }
    
    parser_class = ext_to_parser.get(ext)
    if parser_class:
        return parser_class()
        
    return None
