# Core package initialization
from .analyzer_engine import AnalyzerEngine
from .file_tree_model import FileSystemModel
from .metadata_model import MetadataTableModel
from .risk_analyzer import RiskAnalyzer

# Импортируем парсеры
from .parsers import (
    BaseParser,
    PDFParser,
    DocxParser,
    ImageParser,
    ExcelParser,
    get_parser_for_file
)

__all__ = [
    'AnalyzerEngine',
    'FileSystemModel',
    'MetadataTableModel',
    'RiskAnalyzer',
    'BaseParser',
    'PDFParser',
    'DocxParser',
    'ImageParser',
    'ExcelParser',
    'get_parser_for_file'
]
